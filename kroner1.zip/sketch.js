let loofa;
let maman;
let awesome;

function preload() {
  loofa = loadImage('loofa.jpg');
  maman = loadImage('maman.png');
  awesome = loadImage('awesome.png');
}

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  background(0, 255, 0, 1);
  
  image(loofa, 50, 50, 100, 100);
  image(maman, mouseX - 50, mouseY - 50, 100, 100);
  image(awesome, 0, 200, 400, 200);
  
  fill(255, 0, 0, 1);
  textSize(20);
  textFont('Comic Sans MS');
  stroke(100);
  text('the battle of toulouse', 190, 200);
}