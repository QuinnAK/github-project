function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  let x = 42
  print("The meaning of life, the universe, and everything: " + x);
  angleMode(DEGREES);
}

function draw() {
  background(10, 0, 75, 1);
  strokeWeight(0);
  
  push();
  fill(5, 0, 200, .75);
  translate(100, 100);
  rect(0, 0, 5, 250);
  rect(10, 0, 5, 250);
  rect(20, 0, 5, 250);
  rect(30, 0, 5, 250);
  rect(40, 0, 5, 250);
  rect(50, 0, 5, 250);
  rect(60, 0, 5, 250);
  rect(70, 0, 5, 250);
  rect(80, 0, 5, 250);
  rect(90, 0, 5, 250);
  rect(100, 0, 5, 250);
  rect(110, 0, 5, 250);
  rect(120, 0, 5, 250);
  rect(130, 0, 5, 250);
  rect(140, 0, 5, 250);
  rect(150, 0, 5, 250);
  rect(160, 0, 5, 250);
  rect(170, 0, 5, 250);
  rect(180, 0, 5, 250);
  rect(190, 0, 5, 250);
  rect(200, 0, 5, 250);
  pop();
  
  push();
  fill(10, 0, 75, 1);
  rect(0, 0, 400, 150);
  rotate(15);
  rect(0, 75, 400, 10);
  rect(0, 100, 400, 12.5);
  rect(0, 125, 400, 12.5);
  rect(0, 150, 400, 12.5);
  rect(0, 175, 400, 12.5);
  rect(0, 200, 400, 12.5);
  rect(0, 225, 400, 12.5);
  rect(0, 250, 400, 12.5);
  rect(0, 275, 400, 12.5);
  rect(0, 300, 400, 12.5);
  
  push();
  fill(255, 255, 0, .95);
  translate(200, 75);
  rotate(22.5);
  rect(75, 0, 10, 100);
  rect(75, 99, 50, 10);
  rect(124, 99, 10, 100);
  pop();
  
  pop();
  
  push();
  strokeWeight(3);
  fill(200, 200, 200, 100);
  rect(85, 85, 230, 100);
  scale(.8);
  rect(135, 118.5, 230, 100);
  pop();
}