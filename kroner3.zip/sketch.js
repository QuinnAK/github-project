function setup() {
  createCanvas(400, 400);
  frameRate(30);
}

let coolio = 50;
let sweet = 20;
let a = 100;
let b = 300;

function draw() {
  background(220);
  fill (coolio);
  strokeWeight(sweet);
  rect(100, 100, 200, 200);
  noFill();
  beginShape();
  vertex(a, a);
  vertex(b, a);
  vertex(b, b);
  vertex(a, b);
  endShape(CLOSE);
}

function mousePressed() {
  if (sweet === 20) {
    sweet = 0;
  } else {
    sweet = 20;
  }
}

function mouseClicked() {
  if (coolio === 50) {
    coolio = 220;
  } else {
    coolio = 50;
    for (a = 100; a > 0;) {
      a = a - 1;
    }
    for (b = 300; b < 400;) {
      b = b + 1;
    }
  }
}